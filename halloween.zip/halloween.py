import turtle
import random

t=turtle.Pen()
